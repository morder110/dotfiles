https://www.iconshock.com/freeicons/collection/pixelarticons-icons

We are missing:
- 4G
- 4K
- 4K border
- 5G